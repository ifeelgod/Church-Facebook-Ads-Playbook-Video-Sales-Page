export interface Sermon {
  id: string;
  title: string;
  author: string;
  scripture: string;
  description: string;
  content: string;
  research: string;
  tags: string[];
  createdAt: Date;
  downloads: number;
  denomination?: string;
  theologicalInfluences?: string[];
}

export interface User {
  id: string;
  name: string;
  email: string;
  hasPostedSermon: boolean;
  denomination?: string;
  theologicalInfluences?: string[];
  newsletterSubscribed: boolean;
  emailVerified: boolean;
}

export interface Registration {
  name: string;
  email: string;
  denomination?: string;
  theologicalInfluences?: string[];
  newsletterSubscribed: boolean;
  sermon: {
    title: string;
    scripture: string;
    outline: string;
    researchNotes: string;
  };
}

export interface SermonUpload {
  title: string;
  scripture: string;
  outline: string;
  researchNotes: string;
}