import { createClient } from '@supabase/supabase-js';


// Initialize Supabase client
// Using direct values from project configuration
const supabaseUrl = 'https://kezsbpjszdfyhjurnftj.supabase.co';
const supabaseKey = 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6ImtlenNicGpzemRmeWhqdXJuZnRqIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NTAwMzgwMTMsImV4cCI6MjA2NTYxNDAxM30.yajTN1RBWzCR2ffoYpvECHS2yfPGr8mJ8xiYdzRIDQc';
const supabase = createClient(supabaseUrl, supabaseKey);


export { supabase };