import { useState, useEffect } from 'react';
import { Sermon, User } from '@/types/sermon';
import { toast } from '@/components/ui/use-toast';

const STORAGE_KEY = 'sermonshare-data';

interface SermonData {
  sermons: Sermon[];
  currentUser: User;
}

const defaultUser: User = {
  id: 'user-1',
  name: 'Guest User',
  email: 'guest@example.com',
  hasPostedSermon: false
};

const sampleSermons: Sermon[] = [
  {
    id: '1',
    title: 'The Power of Faith',
    author: 'Pastor Johnson',
    scripture: 'Hebrews 11:1-6',
    description: 'Exploring what it means to have faith and how it transforms our lives.',
    content: 'Faith is the substance of things hoped for, the evidence of things not seen. In this sermon, we explore the transformative power of faith in our daily lives...',
    research: 'Historical context of Hebrews 11. Greek word "pistis" meaning faith/trust. Commentary from Matthew Henry and John MacArthur...',
    tags: ['faith', 'trust', 'transformation'],
    createdAt: new Date('2024-01-15'),
    downloads: 45
  },
  {
    id: '2',
    title: 'Love Your Neighbor',
    author: 'Rev. Smith',
    scripture: 'Matthew 22:37-39',
    description: 'Understanding the greatest commandments and practical ways to love others.',
    content: 'Jesus said the greatest commandment is to love God with all your heart, soul, and mind. The second is like it: love your neighbor as yourself...',
    research: 'Rabbinical teachings on love. Cultural context of neighborliness in ancient Palestine. Cross-references to 1 John 4:20-21...',
    tags: ['love', 'community', 'commandments'],
    createdAt: new Date('2024-01-10'),
    downloads: 32
  }
];

export const useSermons = () => {
  const [data, setData] = useState<SermonData>(() => {
    const stored = localStorage.getItem(STORAGE_KEY);
    if (stored) {
      const parsed = JSON.parse(stored);
      return {
        sermons: parsed.sermons.map((s: any) => ({ ...s, createdAt: new Date(s.createdAt) })),
        currentUser: parsed.currentUser
      };
    }
    return { sermons: sampleSermons, currentUser: defaultUser };
  });

  useEffect(() => {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(data));
  }, [data]);

  const addSermon = (sermonData: Omit<Sermon, 'id' | 'createdAt' | 'downloads'>) => {
    const newSermon: Sermon = {
      ...sermonData,
      id: Date.now().toString(),
      createdAt: new Date(),
      downloads: 0
    };
    
    setData(prev => ({
      sermons: [newSermon, ...prev.sermons],
      currentUser: { ...prev.currentUser, hasPostedSermon: true }
    }));
    
    toast({
      title: 'Sermon Added!',
      description: 'Your sermon has been shared with the community.'
    });
  };

  const downloadSermon = (sermon: Sermon) => {
    if (!data.currentUser.hasPostedSermon) {
      toast({
        title: 'Access Denied',
        description: 'Please share a sermon first to download others.',
        variant: 'destructive'
      });
      return;
    }
    
    setData(prev => ({
      ...prev,
      sermons: prev.sermons.map(s => 
        s.id === sermon.id ? { ...s, downloads: s.downloads + 1 } : s
      )
    }));
    
    // Create download
    const content = `${sermon.title}\n\nBy: ${sermon.author}\nScripture: ${sermon.scripture}\n\n${sermon.description}\n\n--- SERMON CONTENT ---\n${sermon.content}\n\n--- RESEARCH & NOTES ---\n${sermon.research}`;
    const blob = new Blob([content], { type: 'text/plain' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `${sermon.title.replace(/[^a-z0-9]/gi, '_')}.txt`;
    a.click();
    URL.revokeObjectURL(url);
    
    toast({
      title: 'Download Started',
      description: `Downloading "${sermon.title}"`
    });
  };

  return {
    sermons: data.sermons,
    currentUser: data.currentUser,
    canDownload: data.currentUser.hasPostedSermon,
    addSermon,
    downloadSermon
  };
};