import React, { createContext, useContext, useState, useEffect } from 'react';
import { User, Registration } from '../types/sermon';
import { supabase } from '@/lib/supabase';

interface AppContextType {
  sidebarOpen: boolean;
  toggleSidebar: () => void;
  currentUser: User | null;
  registerUser: (registration: Registration) => Promise<void>;
  loginUser: (email: string) => void;
  logoutUser: () => void;
  isRegistered: boolean;
  pendingVerification: boolean;
}

const defaultAppContext: AppContextType = {
  sidebarOpen: false,
  toggleSidebar: () => {},
  currentUser: null,
  registerUser: async () => {},
  loginUser: () => {},
  logoutUser: () => {},
  isRegistered: false,
  pendingVerification: false,
};

const AppContext = createContext<AppContextType>(defaultAppContext);

export const useAppContext = () => useContext(AppContext);

export const AppProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [sidebarOpen, setSidebarOpen] = useState(false);
  const [currentUser, setCurrentUser] = useState<User | null>(null);
  const [pendingVerification, setPendingVerification] = useState(false);

  const toggleSidebar = () => {
    setSidebarOpen(prev => !prev);
  };

  const registerUser = async (registration: Registration) => {
    try {
      // Validate all required fields
      if (!registration.name || !registration.email) {
        throw new Error('Name and email are required');
      }
      
      const { title, scripture, outline, researchNotes } = registration.sermon;
      if (!title || !scripture || !outline || !researchNotes) {
        throw new Error('All sermon fields are required: Title, Scripture, Outline, and Research Notes');
      }

      // Check if email already exists
      const { data: existingUser } = await supabase
        .from('users')
        .select('email')
        .eq('email', registration.email)
        .single();

      if (existingUser) {
        throw new Error('Email already registered');
      }

      // Generate verification token
      const verificationToken = Math.random().toString(36).substring(2, 15) + Math.random().toString(36).substring(2, 15);

      // Insert user into database
      const { data: userData, error: userError } = await supabase
        .from('users')
        .insert({
          name: registration.name,
          email: registration.email,
          denomination: registration.denomination,
          theological_influences: registration.theologicalInfluences,
          newsletter_subscribed: registration.newsletterSubscribed,
          email_verified: false,
          verification_token: verificationToken
        })
        .select()
        .single();

      if (userError) {
        console.error('User insert error:', userError);
        throw new Error('Failed to create user account');
      }

      // Insert sermon
      const { error: sermonError } = await supabase
        .from('sermons')
        .insert({
          title: registration.sermon.title,
          author: registration.name,
          scripture: registration.sermon.scripture,
          description: registration.sermon.outline.substring(0, 200),
          content: registration.sermon.outline,
          research: registration.sermon.researchNotes,
          tags: [],
          downloads: 0,
          denomination: registration.denomination,
          theological_influences: registration.theologicalInfluences,
          user_id: userData.id
        });

      if (sermonError) {
        console.error('Sermon insert error:', sermonError);
        // Clean up user if sermon insert fails
        await supabase.from('users').delete().eq('id', userData.id);
        throw new Error('Failed to upload sermon');
      }

      // Send verification email
      try {
        const response = await fetch('https://kezsbpjszdfyhjurnftj.supabase.co/functions/v1/035716fb-a639-483a-9538-2d02e67f8ae2', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ 
            email: registration.email, 
            name: registration.name,
            token: verificationToken
          })
        });

        if (!response.ok) {
          throw new Error('Failed to send verification email');
        }
      } catch (emailError) {
        console.error('Email sending error:', emailError);
        // Don't fail registration if email fails, just warn user
        alert('Registration successful, but verification email failed to send. Please contact support.');
      }

      setPendingVerification(true);
      alert('Registration successful! Please check your email to verify your account.');
    } catch (error) {
      console.error('Registration error:', error);
      const message = error instanceof Error ? error.message : 'Registration failed. Please try again.';
      throw new Error(message);
    }
  };

  const loginUser = async (email: string) => {
    try {
      const { data, error } = await supabase
        .from('users')
        .select('*')
        .eq('email', email)
        .eq('email_verified', true)
        .single();

      if (error || !data) {
        alert('User not found or email not verified');
        return;
      }

      const user: User = {
        id: data.id,
        name: data.name,
        email: data.email,
        hasPostedSermon: true,
        denomination: data.denomination,
        theologicalInfluences: data.theological_influences,
        newsletterSubscribed: data.newsletter_subscribed,
        emailVerified: data.email_verified
      };

      setCurrentUser(user);
    } catch (error) {
      console.error('Login error:', error);
      alert('Login failed');
    }
  };

  const logoutUser = () => {
    setCurrentUser(null);
    setPendingVerification(false);
  };

  return (
    <AppContext.Provider
      value={{
        sidebarOpen,
        toggleSidebar,
        currentUser,
        registerUser,
        loginUser,
        logoutUser,
        isRegistered: !!currentUser,
        pendingVerification,
      }}
    >
      {children}
    </AppContext.Provider>
  );
};