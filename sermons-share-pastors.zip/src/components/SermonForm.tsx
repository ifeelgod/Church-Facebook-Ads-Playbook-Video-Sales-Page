import { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Button } from '@/components/ui/button';
import { Label } from '@/components/ui/label';
import { Badge } from '@/components/ui/badge';
import { X, Plus } from 'lucide-react';
import { Sermon } from '@/types/sermon';

interface SermonFormProps {
  onSubmit: (sermon: Omit<Sermon, 'id' | 'createdAt' | 'downloads'>) => void;
  onCancel: () => void;
}

export const SermonForm = ({ onSubmit, onCancel }: SermonFormProps) => {
  const [formData, setFormData] = useState({
    title: '',
    author: '',
    scripture: '',
    description: '',
    content: '',
    research: '',
    tags: [] as string[],
    denomination: '',
    theologicalInfluences: [] as string[]
  });
  const [newTag, setNewTag] = useState('');
  const [newInfluence, setNewInfluence] = useState('');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!formData.title || !formData.content || !formData.research) return;
    onSubmit(formData);
  };

  const addTag = () => {
    if (newTag.trim() && !formData.tags.includes(newTag.trim())) {
      setFormData(prev => ({ ...prev, tags: [...prev.tags, newTag.trim()] }));
      setNewTag('');
    }
  };

  const removeTag = (tag: string) => {
    setFormData(prev => ({ ...prev, tags: prev.tags.filter(t => t !== tag) }));
  };

  const addInfluence = () => {
    if (newInfluence.trim() && !formData.theologicalInfluences.includes(newInfluence.trim())) {
      setFormData(prev => ({ ...prev, theologicalInfluences: [...prev.theologicalInfluences, newInfluence.trim()] }));
      setNewInfluence('');
    }
  };

  const removeInfluence = (influence: string) => {
    setFormData(prev => ({ ...prev, theologicalInfluences: prev.theologicalInfluences.filter(i => i !== influence) }));
  };

  return (
    <Card className="max-w-4xl mx-auto">
      <CardHeader className="bg-gradient-to-r from-blue-500 to-purple-600 text-white">
        <CardTitle>Submit Your Sermon</CardTitle>
      </CardHeader>
      <CardContent className="p-6">
        <form onSubmit={handleSubmit} className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <Label htmlFor="title">Sermon Title *</Label>
              <Input
                id="title"
                value={formData.title}
                onChange={(e) => setFormData(prev => ({ ...prev, title: e.target.value }))}
                required
              />
            </div>
            <div>
              <Label htmlFor="author">Author</Label>
              <Input
                id="author"
                value={formData.author}
                onChange={(e) => setFormData(prev => ({ ...prev, author: e.target.value }))}
              />
            </div>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <Label htmlFor="scripture">Scripture Reference</Label>
              <Input
                id="scripture"
                value={formData.scripture}
                onChange={(e) => setFormData(prev => ({ ...prev, scripture: e.target.value }))}
                placeholder="e.g., John 3:16-21"
              />
            </div>
            <div>
              <Label htmlFor="denomination">Denomination</Label>
              <Input
                id="denomination"
                value={formData.denomination}
                onChange={(e) => setFormData(prev => ({ ...prev, denomination: e.target.value }))}
                placeholder="e.g., Baptist, Methodist"
              />
            </div>
          </div>
          <div>
            <Label htmlFor="description">Description</Label>
            <Textarea
              id="description"
              value={formData.description}
              onChange={(e) => setFormData(prev => ({ ...prev, description: e.target.value }))}
              rows={3}
            />
          </div>
          <div>
            <Label htmlFor="content">Sermon Content *</Label>
            <Textarea
              id="content"
              value={formData.content}
              onChange={(e) => setFormData(prev => ({ ...prev, content: e.target.value }))}
              rows={8}
              required
            />
          </div>
          <div>
            <Label htmlFor="research">Research & Notes *</Label>
            <Textarea
              id="research"
              value={formData.research}
              onChange={(e) => setFormData(prev => ({ ...prev, research: e.target.value }))}
              rows={6}
              required
            />
          </div>
          <div>
            <Label>Theological Influences</Label>
            <div className="flex gap-2 mb-2">
              <Input
                value={newInfluence}
                onChange={(e) => setNewInfluence(e.target.value)}
                placeholder="Add theological influence"
                onKeyPress={(e) => e.key === 'Enter' && (e.preventDefault(), addInfluence())}
              />
              <Button type="button" onClick={addInfluence} size="sm">
                <Plus className="w-4 h-4" />
              </Button>
            </div>
            <div className="flex flex-wrap gap-1 mb-4">
              {formData.theologicalInfluences.map((influence) => (
                <Badge key={influence} variant="outline" className="flex items-center gap-1">
                  {influence}
                  <X className="w-3 h-3 cursor-pointer" onClick={() => removeInfluence(influence)} />
                </Badge>
              ))}
            </div>
          </div>
          <div>
            <Label>Tags</Label>
            <div className="flex gap-2 mb-2">
              <Input
                value={newTag}
                onChange={(e) => setNewTag(e.target.value)}
                placeholder="Add a tag"
                onKeyPress={(e) => e.key === 'Enter' && (e.preventDefault(), addTag())}
              />
              <Button type="button" onClick={addTag} size="sm">
                <Plus className="w-4 h-4" />
              </Button>
            </div>
            <div className="flex flex-wrap gap-1">
              {formData.tags.map((tag) => (
                <Badge key={tag} variant="secondary" className="flex items-center gap-1">
                  {tag}
                  <X className="w-3 h-3 cursor-pointer" onClick={() => removeTag(tag)} />
                </Badge>
              ))}
            </div>
          </div>
          <div className="flex gap-2 pt-4">
            <Button type="submit" className="bg-gradient-to-r from-blue-500 to-purple-600 hover:from-blue-600 hover:to-purple-700">
              Submit Sermon
            </Button>
            <Button type="button" variant="outline" onClick={onCancel}>
              Cancel
            </Button>
          </div>
        </form>
      </CardContent>
    </Card>
  );
};