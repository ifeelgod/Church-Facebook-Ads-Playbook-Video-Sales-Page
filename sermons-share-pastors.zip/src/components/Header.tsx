import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { Search, Plus, BookOpen, Users } from 'lucide-react';

interface HeaderProps {
  searchTerm: string;
  onSearchChange: (value: string) => void;
  onAddSermon: () => void;
  canAddSermon: boolean;
  totalSermons: number;
  totalUsers: number;
}

export const Header = ({ 
  searchTerm, 
  onSearchChange, 
  onAddSermon, 
  canAddSermon, 
  totalSermons, 
  totalUsers 
}: HeaderProps) => {
  return (
    <div className="bg-gradient-to-r from-blue-600 via-purple-600 to-indigo-700 text-white">
      <div className="container mx-auto px-4 py-8">
        <div className="text-center mb-8">
          <h1 className="text-4xl font-bold mb-2 flex items-center justify-center gap-3">
            <BookOpen className="w-10 h-10" />
            SermonShare
          </h1>
          <p className="text-xl opacity-90">
            Share Quality Sermons • Build Community • Grow Together
          </p>
        </div>
        
        <div className="flex flex-col md:flex-row gap-4 items-center justify-between">
          <div className="flex items-center gap-4">
            <Badge variant="secondary" className="bg-white/20 text-white border-white/30">
              <BookOpen className="w-4 h-4 mr-1" />
              {totalSermons} Sermons
            </Badge>
            <Badge variant="secondary" className="bg-white/20 text-white border-white/30">
              <Users className="w-4 h-4 mr-1" />
              {totalUsers} Contributors
            </Badge>
          </div>
          
          <div className="flex gap-3 w-full md:w-auto">
            <div className="relative flex-1 md:w-80">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 w-4 h-4 text-gray-400" />
              <Input
                placeholder="Search sermons, authors, or scripture..."
                value={searchTerm}
                onChange={(e) => onSearchChange(e.target.value)}
                className="pl-10 bg-white/10 border-white/30 text-white placeholder:text-white/70"
              />
            </div>
            
            <Button
              onClick={onAddSermon}
              disabled={!canAddSermon}
              className="bg-white text-blue-600 hover:bg-gray-100 font-semibold"
            >
              <Plus className="w-4 h-4 mr-2" />
              Add Sermon
            </Button>
          </div>
        </div>
        
        {!canAddSermon && (
          <div className="mt-4 p-3 bg-yellow-500/20 border border-yellow-400/30 rounded-lg text-center">
            <p className="text-sm">
              💡 <strong>Want to download sermons?</strong> Share one of your own quality sermons first to unlock access!
            </p>
          </div>
        )}
      </div>
    </div>
  );
};