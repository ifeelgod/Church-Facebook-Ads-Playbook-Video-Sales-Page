import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Download, Calendar, User } from 'lucide-react';
import { Sermon } from '@/types/sermon';

interface SermonModalProps {
  sermon: Sermon | null;
  isOpen: boolean;
  onClose: () => void;
  onDownload: (sermon: Sermon) => void;
  canDownload: boolean;
  showFullContent: boolean;
}

const SermonModal = ({ sermon, isOpen, onClose, onDownload, canDownload, showFullContent }: SermonModalProps) => {
  if (!sermon) return null;

  const getContentDisplay = () => {
    if (showFullContent) return sermon.content;
    return sermon.content.length > 300 ? sermon.content.substring(0, 300) + '...' : sermon.content;
  };

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-4xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="text-2xl font-bold text-gray-800">{sermon.title}</DialogTitle>
          <div className="flex items-center gap-4 text-sm text-gray-600">
            <div className="flex items-center gap-1">
              <User className="w-4 h-4" />
              {sermon.author}
            </div>
            <div className="flex items-center gap-1">
              <Calendar className="w-4 h-4" />
              {sermon.createdAt.toLocaleDateString()}
            </div>
            <div>{sermon.downloads} downloads</div>
          </div>
          {sermon.denomination && (
            <Badge variant="outline">{sermon.denomination}</Badge>
          )}
        </DialogHeader>
        
        <div className="space-y-6">
          <div>
            <h3 className="font-semibold text-blue-600 mb-2">Scripture Reference</h3>
            <p className="text-lg font-medium">{sermon.scripture}</p>
          </div>
          
          {sermon.description && (
            <div>
              <h3 className="font-semibold text-gray-800 mb-2">Description</h3>
              <p className="text-gray-700">{sermon.description}</p>
            </div>
          )}
          
          <div>
            <h3 className="font-semibold text-gray-800 mb-2">Sermon Content</h3>
            <div className="bg-gray-50 p-4 rounded-lg">
              <pre className="whitespace-pre-wrap text-sm text-gray-700">{getContentDisplay()}</pre>
              {!showFullContent && sermon.content.length > 300 && (
                <p className="text-xs text-blue-600 mt-2 italic">
                  Submit your own sermon to view full content
                </p>
              )}
            </div>
          </div>
          
          {showFullContent && (
            <div>
              <h3 className="font-semibold text-gray-800 mb-2">Research & Notes</h3>
              <div className="bg-blue-50 p-4 rounded-lg">
                <pre className="whitespace-pre-wrap text-sm text-gray-700">{sermon.research}</pre>
              </div>
            </div>
          )}
          
          {sermon.theologicalInfluences && sermon.theologicalInfluences.length > 0 && (
            <div>
              <h3 className="font-semibold text-gray-800 mb-2">Theological Influences</h3>
              <div className="flex flex-wrap gap-2">
                {sermon.theologicalInfluences.map((influence) => (
                  <Badge key={influence} variant="outline">{influence}</Badge>
                ))}
              </div>
            </div>
          )}
          
          {sermon.tags.length > 0 && (
            <div>
              <h3 className="font-semibold text-gray-800 mb-2">Tags</h3>
              <div className="flex flex-wrap gap-2">
                {sermon.tags.map((tag) => (
                  <Badge key={tag} variant="secondary">{tag}</Badge>
                ))}
              </div>
            </div>
          )}
          
          <div className="flex gap-2 pt-4 border-t">
            <Button 
              onClick={() => onDownload(sermon)}
              disabled={!canDownload}
              className="bg-gradient-to-r from-blue-500 to-purple-600 hover:from-blue-600 hover:to-purple-700"
              title={!canDownload ? "Submit your own sermon to download" : ""}
            >
              <Download className="w-4 h-4 mr-2" />
              Download Sermon
            </Button>
            <Button variant="outline" onClick={onClose}>
              Close
            </Button>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
};

export default SermonModal;