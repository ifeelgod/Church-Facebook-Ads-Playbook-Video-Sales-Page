import { useState } from 'react';
import { Button } from './ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from './ui/card';
import { Badge } from './ui/badge';
import { BookOpen, Users, Download, Star } from 'lucide-react';
import { RegistrationForm } from './RegistrationForm';
import { useAppContext } from '../contexts/AppContext';

const SplashScreen = () => {
  const [showRegistration, setShowRegistration] = useState(false);
  const [showLogin, setShowLogin] = useState(false);
  const [loginEmail, setLoginEmail] = useState('');
  const { registerUser, loginUser, pendingVerification } = useAppContext();

  const sampleSermons = [
    {
      title: "Walking in Faith Through Trials",
      author: "Pastor Johnson",
      scripture: "James 1:2-4",
      snippet: "Consider it pure joy, my brothers and sisters, whenever you face trials of many kinds...",
      tags: ["Faith", "Trials", "Growth"]
    },
    {
      title: "The Power of Forgiveness",
      author: "Rev. Smith",
      scripture: "Matthew 6:14-15",
      snippet: "For if you forgive other people when they sin against you, your heavenly Father...",
      tags: ["Forgiveness", "Grace", "Relationships"]
    },
    {
      title: "Living with Purpose",
      author: "Dr. Williams",
      scripture: "Jeremiah 29:11",
      snippet: "For I know the plans I have for you, declares the Lord, plans to prosper you...",
      tags: ["Purpose", "Hope", "Future"]
    }
  ];

  if (pendingVerification) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-blue-50 to-purple-50">
        <Card className="w-full max-w-md mx-auto">
          <CardHeader>
            <CardTitle>Check Your Email</CardTitle>
            <CardDescription>
              We've sent a verification link to your email address. Please click the link to complete your registration.
            </CardDescription>
          </CardHeader>
          <CardContent>
            <Button onClick={() => window.location.reload()} className="w-full">
              I've Verified My Email
            </Button>
          </CardContent>
        </Card>
      </div>
    );
  }

  if (showRegistration) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-blue-50 to-purple-50 p-4">
        <RegistrationForm 
          onRegister={registerUser}
          onCancel={() => setShowRegistration(false)}
        />
      </div>
    );
  }

  if (showLogin) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-blue-50 to-purple-50">
        <Card className="w-full max-w-md mx-auto">
          <CardHeader>
            <CardTitle>Login to SermonShare</CardTitle>
            <CardDescription>Enter your email to access your account</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              <input
                type="email"
                placeholder="Email address"
                value={loginEmail}
                onChange={(e) => setLoginEmail(e.target.value)}
                className="w-full p-2 border rounded"
              />
              <div className="flex gap-2">
                <Button onClick={() => loginUser(loginEmail)} className="flex-1">
                  Login
                </Button>
                <Button variant="outline" onClick={() => setShowLogin(false)}>
                  Cancel
                </Button>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-purple-50">
      <div className="bg-white shadow-sm border-b">
        <div className="container mx-auto px-4 py-4 flex justify-between items-center">
          <h1 className="text-2xl font-bold bg-gradient-to-r from-blue-600 to-purple-600 bg-clip-text text-transparent">
            SermonShare
          </h1>
          <div className="flex gap-2">
            <Button variant="outline" onClick={() => setShowLogin(true)}>Login</Button>
            <Button onClick={() => setShowRegistration(true)}>Join Now</Button>
          </div>
        </div>
      </div>

      <div className="container mx-auto px-4 py-12 text-center">
        <h2 className="text-4xl font-bold text-gray-900 mb-4">
          Share Quality Sermons with Fellow Pastors
        </h2>
        <p className="text-xl text-gray-600 mb-8 max-w-2xl mx-auto">
          Join our community of pastors sharing sermon outlines, research notes, and biblical insights. 
          Contribute your own sermon to unlock full access to our growing library.
        </p>
        
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-12">
          <div className="bg-white p-6 rounded-lg shadow-sm">
            <BookOpen className="h-12 w-12 text-blue-600 mx-auto mb-4" />
            <h3 className="font-semibold mb-2">Quality Content</h3>
            <p className="text-gray-600 text-sm">Access sermon outlines, research notes, and biblical insights from experienced pastors.</p>
          </div>
          <div className="bg-white p-6 rounded-lg shadow-sm">
            <Users className="h-12 w-12 text-purple-600 mx-auto mb-4" />
            <h3 className="font-semibold mb-2">Pastor Community</h3>
            <p className="text-gray-600 text-sm">Connect with pastors from various denominations and theological backgrounds.</p>
          </div>
          <div className="bg-white p-6 rounded-lg shadow-sm">
            <Download className="h-12 w-12 text-green-600 mx-auto mb-4" />
            <h3 className="font-semibold mb-2">Easy Access</h3>
            <p className="text-gray-600 text-sm">Download and adapt sermon materials for your congregation's needs.</p>
          </div>
        </div>
      </div>

      <div className="container mx-auto px-4 pb-12">
        <h3 className="text-2xl font-bold text-center mb-8">Sample Sermon Library</h3>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          {sampleSermons.map((sermon, index) => (
            <Card key={index} className="relative">
              <CardHeader>
                <CardTitle className="text-lg">{sermon.title}</CardTitle>
                <CardDescription>by {sermon.author}</CardDescription>
              </CardHeader>
              <CardContent>
                <p className="text-sm text-gray-600 mb-3">
                  <strong>Scripture:</strong> {sermon.scripture}
                </p>
                <p className="text-sm mb-4 line-clamp-3">
                  {sermon.snippet}...
                </p>
                <div className="flex flex-wrap gap-1 mb-4">
                  {sermon.tags.map((tag, tagIndex) => (
                    <Badge key={tagIndex} variant="secondary" className="text-xs">
                      {tag}
                    </Badge>
                  ))}
                </div>
                <div className="absolute inset-0 bg-white/80 backdrop-blur-sm flex items-center justify-center opacity-0 hover:opacity-100 transition-opacity">
                  <div className="text-center">
                    <Star className="h-8 w-8 text-yellow-500 mx-auto mb-2" />
                    <p className="font-semibold mb-2">Register to Access</p>
                    <Button size="sm" onClick={() => setShowRegistration(true)}>
                      Join Now
                    </Button>
                  </div>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
        
        <div className="text-center mt-8">
          <p className="text-gray-600 mb-4">
            This is just a preview. Register to access our full library of sermons!
          </p>
          <Button size="lg" onClick={() => setShowRegistration(true)}>
            Get Full Access - Register Now
          </Button>
        </div>
      </div>
    </div>
  );
};

export default SplashScreen;