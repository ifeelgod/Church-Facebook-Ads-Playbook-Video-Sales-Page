import React, { useState } from 'react';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { Label } from './ui/label';
import { Textarea } from './ui/textarea';
import { Checkbox } from './ui/checkbox';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from './ui/select';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from './ui/card';
import { Registration } from '../types/sermon';
import { Alert, AlertDescription } from './ui/alert';

interface RegistrationFormProps {
  onRegister: (registration: Registration) => void;
  onCancel: () => void;
}

const DENOMINATIONS = [
  'Baptist',
  'Methodist',
  'Presbyterian',
  'Lutheran',
  'Pentecostal',
  'Charismatic',
  'Episcopal',
  'Catholic',
  'Non-denominational',
  'None',
  'Other'
];

export function RegistrationForm({ onRegister, onCancel }: RegistrationFormProps) {
  const [formData, setFormData] = useState<Registration>({
    name: '',
    email: '',
    denomination: '',
    theologicalInfluences: [],
    newsletterSubscribed: false,
    sermon: {
      title: '',
      scripture: '',
      outline: '',
      researchNotes: ''
    }
  });
  
  const [error, setError] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    setIsSubmitting(true);
    
    try {
      // Validate required fields
      if (!formData.name || !formData.email) {
        setError('Name and email are required');
        return;
      }
      
      // Validate sermon fields
      const { title, scripture, outline, researchNotes } = formData.sermon;
      if (!title || !scripture || !outline || !researchNotes) {
        setError('All sermon fields are required: Title, Scripture, Outline, and Research Notes');
        return;
      }
      
      await onRegister(formData);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Registration failed');
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleInfluencesChange = (value: string) => {
    const influences = value.split(',').map(s => s.trim()).filter(s => s.length > 0);
    setFormData(prev => ({ ...prev, theologicalInfluences: influences }));
  };

  return (
    <Card className="w-full max-w-2xl mx-auto">
      <CardHeader>
        <CardTitle>Register for SermonShare</CardTitle>
        <CardDescription>
          Join our community by sharing your first sermon. All fields are required.
        </CardDescription>
      </CardHeader>
      <CardContent>
        <form onSubmit={handleSubmit} className="space-y-4">
          {error && (
            <Alert variant="destructive">
              <AlertDescription>{error}</AlertDescription>
            </Alert>
          )}
          
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <Label htmlFor="name">Full Name *</Label>
              <Input
                id="name"
                value={formData.name}
                onChange={(e) => setFormData(prev => ({ ...prev, name: e.target.value }))}
                required
                disabled={isSubmitting}
              />
            </div>
            <div>
              <Label htmlFor="email">Email *</Label>
              <Input
                id="email"
                type="email"
                value={formData.email}
                onChange={(e) => setFormData(prev => ({ ...prev, email: e.target.value }))}
                required
                disabled={isSubmitting}
              />
            </div>
          </div>
          
          <div>
            <Label htmlFor="denomination">Denomination</Label>
            <Select 
              value={formData.denomination} 
              onValueChange={(value) => setFormData(prev => ({ ...prev, denomination: value }))}
              disabled={isSubmitting}
            >
              <SelectTrigger>
                <SelectValue placeholder="Select denomination" />
              </SelectTrigger>
              <SelectContent>
                {DENOMINATIONS.map(denom => (
                  <SelectItem key={denom} value={denom}>{denom}</SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
          
          <div>
            <Label htmlFor="influences">Theological Influences</Label>
            <Textarea
              id="influences"
              value={formData.theologicalInfluences?.join(', ')}
              onChange={(e) => handleInfluencesChange(e.target.value)}
              placeholder="e.g., John Calvin, C.S. Lewis, N.T. Wright (comma separated)"
              disabled={isSubmitting}
            />
          </div>
          
          <div className="border-t pt-4">
            <h3 className="text-lg font-semibold mb-3">Upload Your Sermon *</h3>
            <div className="space-y-3">
              <div>
                <Label htmlFor="sermonTitle">Sermon Title *</Label>
                <Input
                  id="sermonTitle"
                  value={formData.sermon.title}
                  onChange={(e) => setFormData(prev => ({
                    ...prev,
                    sermon: { ...prev.sermon, title: e.target.value }
                  }))}
                  required
                  disabled={isSubmitting}
                />
              </div>
              <div>
                <Label htmlFor="scripture">Scripture Reference *</Label>
                <Input
                  id="scripture"
                  value={formData.sermon.scripture}
                  onChange={(e) => setFormData(prev => ({
                    ...prev,
                    sermon: { ...prev.sermon, scripture: e.target.value }
                  }))}
                  placeholder="e.g., John 3:16-21"
                  required
                  disabled={isSubmitting}
                />
              </div>
              <div>
                <Label htmlFor="outline">Sermon Outline *</Label>
                <Textarea
                  id="outline"
                  value={formData.sermon.outline}
                  onChange={(e) => setFormData(prev => ({
                    ...prev,
                    sermon: { ...prev.sermon, outline: e.target.value }
                  }))}
                  placeholder="Main points and structure of your sermon"
                  rows={4}
                  required
                  disabled={isSubmitting}
                />
              </div>
              <div>
                <Label htmlFor="research">Research Notes *</Label>
                <Textarea
                  id="research"
                  value={formData.sermon.researchNotes}
                  onChange={(e) => setFormData(prev => ({
                    ...prev,
                    sermon: { ...prev.sermon, researchNotes: e.target.value }
                  }))}
                  placeholder="Background research, commentary references, etc."
                  rows={4}
                  required
                  disabled={isSubmitting}
                />
              </div>
            </div>
          </div>
          
          <div className="flex items-center space-x-2">
            <Checkbox
              id="newsletter"
              checked={formData.newsletterSubscribed}
              onCheckedChange={(checked) => 
                setFormData(prev => ({ ...prev, newsletterSubscribed: !!checked }))
              }
              disabled={isSubmitting}
            />
            <Label htmlFor="newsletter">Subscribe to weekly newsletter</Label>
          </div>
          
          <div className="flex gap-2">
            <Button type="submit" className="flex-1" disabled={isSubmitting}>
              {isSubmitting ? 'Registering...' : 'Register & Upload Sermon'}
            </Button>
            <Button type="button" variant="outline" onClick={onCancel} disabled={isSubmitting}>
              Cancel
            </Button>
          </div>
        </form>
      </CardContent>
    </Card>
  );
}