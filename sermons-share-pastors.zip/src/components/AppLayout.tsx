import { useState, useMemo } from 'react';
import { Header } from './Header';
import { SermonCard } from './SermonCard';
import { SermonForm } from './SermonForm';
import SermonModal from './SermonModal';
import { RegistrationForm } from './RegistrationForm';
import SplashScreen from './SplashScreen';
import { useSermons } from '@/hooks/useSermons';
import { useAppContext } from '@/contexts/AppContext';
import { Sermon } from '@/types/sermon';
import { Button } from './ui/button';
import { Input } from './ui/input';

const AppLayout = () => {
  const { sermons, addSermon, downloadSermon } = useSermons();
  const { currentUser, registerUser, loginUser, isRegistered } = useAppContext();
  const [searchTerm, setSearchTerm] = useState('');
  const [showForm, setShowForm] = useState(false);
  const [showRegistration, setShowRegistration] = useState(false);
  const [showLogin, setShowLogin] = useState(false);
  const [loginEmail, setLoginEmail] = useState('');
  const [selectedSermon, setSelectedSermon] = useState<Sermon | null>(null);

  const filteredSermons = useMemo(() => {
    if (!searchTerm) return sermons;
    const term = searchTerm.toLowerCase();
    return sermons.filter(sermon => 
      sermon.title.toLowerCase().includes(term) ||
      sermon.author.toLowerCase().includes(term) ||
      sermon.scripture.toLowerCase().includes(term) ||
      sermon.tags.some(tag => tag.toLowerCase().includes(term))
    );
  }, [sermons, searchTerm]);

  const canDownload = currentUser?.hasPostedSermon || false;
  const showFullContent = currentUser?.hasPostedSermon || false;

  const handleSubmitSermon = (sermonData: Omit<Sermon, 'id' | 'createdAt' | 'downloads'>) => {
    addSermon(sermonData);
    if (currentUser) {
      (window as any).updateUserSermonStatus?.(currentUser.id);
    }
    setShowForm(false);
  };

  const handleLogin = () => {
    if (loginEmail) {
      loginUser(loginEmail);
      setShowLogin(false);
      setLoginEmail('');
    }
  };

  // Show splash screen if not registered
  if (!isRegistered) {
    if (showRegistration) {
      return (
        <div className="min-h-screen bg-gradient-to-br from-blue-50 to-purple-50 flex items-center justify-center p-4">
          <div className="w-full max-w-md">
            <RegistrationForm 
              onRegister={(reg) => {
                registerUser(reg);
                setShowRegistration(false);
              }}
              onCancel={() => setShowRegistration(false)}
            />
          </div>
        </div>
      );
    }
    
    if (showLogin) {
      return (
        <div className="min-h-screen bg-gradient-to-br from-blue-50 to-purple-50 flex items-center justify-center p-4">
          <div className="w-full max-w-md">
            <div className="bg-white p-6 rounded-lg shadow-lg">
              <h2 className="text-xl font-bold mb-4">Login</h2>
              <Input 
                type="email" 
                placeholder="Enter your email" 
                value={loginEmail}
                onChange={(e) => setLoginEmail(e.target.value)}
                className="mb-4"
              />
              <div className="flex gap-2">
                <Button onClick={handleLogin} className="flex-1">Login</Button>
                <Button variant="outline" onClick={() => setShowLogin(false)}>Cancel</Button>
              </div>
            </div>
          </div>
        </div>
      );
    }
    
    return (
      <SplashScreen 
        onShowRegistration={() => setShowRegistration(true)}
        onShowLogin={() => setShowLogin(true)}
      />
    );
  }

  if (showForm) {
    return (
      <div className="min-h-screen bg-gray-50 py-8">
        <div className="container mx-auto px-4">
          <SermonForm 
            onSubmit={handleSubmitSermon}
            onCancel={() => setShowForm(false)}
          />
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50">
      <Header
        searchTerm={searchTerm}
        onSearchChange={setSearchTerm}
        onAddSermon={() => setShowForm(true)}
        canAddSermon={true}
        totalSermons={sermons.length}
        totalUsers={new Set(sermons.map(s => s.author)).size}
      />
      
      <div className="container mx-auto px-4 py-8">
        {!currentUser?.hasPostedSermon && (
          <div className="bg-blue-50 border border-blue-200 rounded-lg p-4 mb-6">
            <p className="text-blue-800">
              📝 Submit your own sermon to unlock full access to all sermon content and downloads!
            </p>
          </div>
        )}
        
        {filteredSermons.length === 0 ? (
          <div className="text-center py-12">
            <div className="text-6xl mb-4">📚</div>
            <h3 className="text-xl font-semibold text-gray-600 mb-2">
              {searchTerm ? 'No sermons found' : 'No sermons yet'}
            </h3>
            <p className="text-gray-500">
              {searchTerm ? 'Try adjusting your search terms' : 'Be the first to share a sermon!'}
            </p>
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {filteredSermons.map((sermon) => (
              <SermonCard
                key={sermon.id}
                sermon={sermon}
                onView={(s) => setSelectedSermon(s)}
                onDownload={downloadSermon}
                canDownload={canDownload}
                showFullContent={showFullContent}
              />
            ))}
          </div>
        )}
      </div>
      
      <SermonModal
        sermon={selectedSermon}
        isOpen={!!selectedSermon}
        onClose={() => setSelectedSermon(null)}
        onDownload={downloadSermon}
        canDownload={canDownload}
        showFullContent={showFullContent}
      />
    </div>
  );
};

export default AppLayout;