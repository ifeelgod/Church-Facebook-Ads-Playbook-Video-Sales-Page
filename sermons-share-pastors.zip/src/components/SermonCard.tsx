import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Download, Eye } from 'lucide-react';
import { Sermon } from '@/types/sermon';

interface SermonCardProps {
  sermon: Sermon;
  onView: (sermon: Sermon) => void;
  onDownload: (sermon: Sermon) => void;
  canDownload: boolean;
  showFullContent: boolean;
}

export const SermonCard = ({ sermon, onView, onDownload, canDownload, showFullContent }: SermonCardProps) => {
  const getContentPreview = () => {
    if (showFullContent) return sermon.content;
    return sermon.content.length > 150 ? sermon.content.substring(0, 150) + '...' : sermon.content;
  };

  return (
    <Card className="hover:shadow-lg transition-shadow duration-300 border-l-4 border-l-blue-500">
      <CardHeader className="pb-3">
        <CardTitle className="text-lg font-bold text-gray-800">{sermon.title}</CardTitle>
        <div className="flex items-center justify-between text-sm text-gray-600">
          <span>By {sermon.author}</span>
          <span>{sermon.downloads} downloads</span>
        </div>
        {sermon.denomination && (
          <Badge variant="outline" className="w-fit">{sermon.denomination}</Badge>
        )}
      </CardHeader>
      <CardContent>
        <p className="text-blue-600 font-medium mb-2">{sermon.scripture}</p>
        <p className="text-gray-700 mb-3 line-clamp-2">{sermon.description}</p>
        
        {!showFullContent && (
          <div className="bg-gray-50 p-3 rounded mb-3">
            <p className="text-sm text-gray-600 italic">
              Content preview: {getContentPreview()}
            </p>
            {sermon.content.length > 150 && (
              <p className="text-xs text-blue-600 mt-1">
                Submit your own sermon to view full content
              </p>
            )}
          </div>
        )}
        
        {sermon.theologicalInfluences && sermon.theologicalInfluences.length > 0 && (
          <div className="mb-3">
            <p className="text-xs text-gray-500 mb-1">Theological Influences:</p>
            <div className="flex flex-wrap gap-1">
              {sermon.theologicalInfluences.map((influence) => (
                <Badge key={influence} variant="outline" className="text-xs">
                  {influence}
                </Badge>
              ))}
            </div>
          </div>
        )}
        
        <div className="flex flex-wrap gap-1 mb-4">
          {sermon.tags.map((tag) => (
            <Badge key={tag} variant="secondary" className="text-xs">
              {tag}
            </Badge>
          ))}
        </div>
        
        <div className="flex gap-2">
          <Button onClick={() => onView(sermon)} variant="outline" size="sm" className="flex-1">
            <Eye className="w-4 h-4 mr-1" />
            View
          </Button>
          <Button 
            onClick={() => onDownload(sermon)} 
            disabled={!canDownload}
            size="sm" 
            className="flex-1 bg-gradient-to-r from-blue-500 to-purple-600 hover:from-blue-600 hover:to-purple-700"
            title={!canDownload ? "Submit your own sermon to download" : ""}
          >
            <Download className="w-4 h-4 mr-1" />
            Download
          </Button>
        </div>
      </CardContent>
    </Card>
  );
};